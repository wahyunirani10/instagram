<?php
include "koneksi.php";
$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no'";
$query = mysqli_query($koneksi,$sql);
while ($post= mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Edit</h1>
    
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
        
        <label for="">Foto</label><br>
        <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" ><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt=""><br><br>

        <label for="">Caption</label><br>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br><br>

        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" autocomplete="off"><br><br>
        
        <input type="submit" value="Update" name="update">
    </form>
</body>
</html>
<?php } ?>