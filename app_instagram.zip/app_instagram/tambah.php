<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container mt-5">
<h1 align="center">Tambah</h1>
    <form action="proses_tambah.php" method="post" 
    enctype="multipart/form-data">
<form>
  <div class="mb-3">
    <label for="" class="form-label">Gambar</label>
    <input type="file" name="gambar" id="" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Caption</label>
    <input type="text" name="caption" id="" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Lokasi</label>
    <input type="text" name="lokasi" id="" class="form-control" required>
  </div>
  <button type="submit" value="Simpan" name="simpan" class="btn btn-primary">Simpan</button>
  <a href="index.php" class="btn btn-danger"><i class="bi bi-box-arrow-left"></i>Kembali</a>
</form>

</body>
</html>